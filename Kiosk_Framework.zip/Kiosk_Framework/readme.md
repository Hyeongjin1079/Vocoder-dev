## KIOSK PROJECT

## How to Configuration?

```bash
pip install flask
```

## How to use it?

```bash
python service.py
```

and then connect http://localhost:5000/